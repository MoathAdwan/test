<?php

class Application_Model_DbTable_Music extends Zend_Db_Table_Abstract
{

    protected $_name = 'music';
public function getAllMusic($id)
{
$id = (int)
$id;
return $this->fetchAll('album_id = ' . $id);
 
}

public function getMusic($id)
{
$id = (int)
$id;
$row = $this->fetchRow('id = ' . $id);
if (!$row) {throw new Exception("Could not find row $id");}
return 
$row->toArray();    
}

public function addMusic($id, $title,$duration,$file)
    {
$data = array('title' => $title,
'duration' => $duration,'file' => $file,'album_id' => $id );
$this->insert($data);
    }

public function updateMusic($id, $title, $duration,$file)
    {
$data = array(
'title' => $title,
'duration' => $duration,
   'file' => $file   );
$this->update($data, 'id = '. (int)$id);
    }

public function deleteMusic($id)
    {
$this->delete('id =' . (int)$id);
    }

public function get_page_id($id)
    {
$row = $this->fetchRow('id = ' . $id);
if (!$row) {throw new Exception("Could not find row $id");}
return 
$row->toArray();    
    }

}


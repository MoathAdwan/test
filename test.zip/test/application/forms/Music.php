<?php

class Application_Form_Music extends Zend_Form
{

    public function init()
{
$this->setName('music');
$this->setAttrib('enctype', 'multipart/form-data');
$this->setEnctype(Zend_Form::ENCTYPE_MULTIPART);
$id = new Zend_Form_Element_Hidden('id');
$id->addFilter('Int');


$title = new Zend_Form_Element_Text('title');
$title->setLabel('Title')
->setRequired(true)
->addFilter('StripTags')
->addFilter('StringTrim')
->addValidator('NotEmpty');

$duration = new Zend_Form_Element_Text('duration');

$duration->setLabel('Duration')

->setOptions([
    'format' => 'H:i:s',
])
->setRequired(true)
->addFilter('StripTags')
->addFilter('StringTrim')
->addValidator('NotEmpty');

$file = new Zend_Form_Element_File('file');
$file->setLabel('MP3 file')
->setRequired(true)
->setDestination('/var/www/test/public/mp3')
->addValidator('Extension', true, 'mp3');

$submit = new Zend_Form_Element_Submit('submit');
$submit->setAttrib('id', 'submitbutton');
$this->addElements(array($id, $title,$duration,$file, $submit));
}

}


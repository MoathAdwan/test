<?php

class AlbumController extends Zend_Controller_Action
{
 
    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $albums = new Application_Model_DbTable_Albums();
$this->view->albums = $albums->fetchAll();
    }

    public function addAction()
    {
        $form = new Application_Form_Album();
$form->submit->setLabel('Add');
$this->view->form = $form;
if ($this->getRequest()->isPost()) {
$formData = $this->getRequest()->getPost();
if ($form->isValid($formData)) {
$artist = $form->getValue('artist');
$title = $form->getValue('title');
$albums = new Application_Model_DbTable_Albums();
$albums->addAlbum($artist, $title);
$this->_helper->redirector();
} else {
$form->populate($formData);
}

   } 
    }

    public function editAction()
    {
$form = new Application_Form_Album();
$form->submit->setLabel('Save');
$this->view->form = $form;
if ($this->getRequest()->isPost()) {
$formData = $this->getRequest()->getPost();
if ($form->isValid($formData)) {
$id = (int)$form->getValue('id');
$artist = $form->getValue('artist');
$title = $form->getValue('title');
$albums = new Application_Model_DbTable_Albums();
$albums->updateAlbum($id, $artist, $title);
$this->_helper->redirector();
} else {
$form->populate($formData);
}
} else {
$id = $this->_getParam('id', 0);
if ($id > 0) {
$albums = new Application_Model_DbTable_Albums();
$form->populate($albums->getAlbum($id));
}
}
    }

    public function deleteAction()
    {
      if ($this->getRequest()->isPost()) {
$del = $this->getRequest()->getPost('del');
if ($del == 'Yes') {
$id = $this->getRequest()->getPost('id');
$albums = new Application_Model_DbTable_Albums();
$albums->deleteAlbum($id);
}
$this->_helper->redirector();
} else {
$id = $this->_getParam('id', 0);
$albums = new Application_Model_DbTable_Albums();
$this->view->album = $albums->getAlbum($id);

   } 
    
    }

    public function viewAction()
    {
        $_SESSION['id']= $this->_getParam('id', 0);
$id=$_SESSION['id'];
$music = new Application_Model_DbTable_Music();
$this->view->music = $music->getAllMusic($id);

    }

    public function addmAction()
    {
        $form = new Application_Form_Music();
$form->submit->setLabel('Add music');
$this->view->form = $form;
if ($this->getRequest()->isPost()) {
$formData = $this->getRequest()->getPost();
if ($form->isValid($formData)) {
$id = $this->_getParam('id', 0);
$duration = $form->getValue('duration');
$title = $form->getValue('title');


 $upload = new Zend_File_Transfer_Adapter_Http();
           


            try { 
                 $upload->receive();
                 $location = $upload->getFileName('file');
$name=substr($location,5);
            }                
            catch(Zend_File_Transfer_Exception $e){
                 $e->getMessage();
            }

$music = new Application_Model_DbTable_Music();
$music->addMusic($id,$title, $duration,$name);
$this->_redirect('album/view/id/'.$id);

} else {
$form->populate($formData);
}

   } 
    }

    public function editmAction()
    {
        $form = new Application_Form_Music();
$form->submit->setLabel('Save');
$this->view->form = $form;
if ($this->getRequest()->isPost()) {
$formData = $this->getRequest()->getPost();
if ($form->isValid($formData)) {
$id = (int)$form->getValue('id');
$title = $form->getValue('title');
$duration = $form->getValue('duration');
$upload = new Zend_File_Transfer_Adapter_Http();
           


            try { 
                 $upload->receive();
                 $location = $upload->getFileName('file');
$name=substr($location,5);
            }                
            catch(Zend_File_Transfer_Exception $e){
                 $e->getMessage();
            }

$music = new Application_Model_DbTable_Music();
$music->updateMusic($id, $title, $duration,$name);
$row=$music->get_page_id($id);
$page_id=$row['album_id'];
$this->_redirect('album/view/id/'.$page_id);
} else {
$form->populate($formData);
}
} else {
$id = $this->_getParam('id', 0);
if ($id > 0) {
$music = new Application_Model_DbTable_Music();
$form->populate($music->getMusic($id));
}
}
    }

    public function deletemAction()
    {
       if ($this->getRequest()->isPost()) {
$del = $this->getRequest()->getPost('del');
$id = $this->getRequest()->getPost('id');
$music = new Application_Model_DbTable_Music();
$row=$music->get_page_id($id);
$page_id=$row['album_id'];
if ($del == 'Yes') {
$music->deleteMusic($id);
}
if ($del == 'No') {

$this->_redirect('album/view/id/'.$page_id);
}
$this->_redirect('album/view/id/'.$page_id);
} else {
$id = $this->_getParam('id', 0);
$music = new Application_Model_DbTable_Music();
$this->view->music = $music->getMusic($id);

   } 
    }


}





















